// export const API = "http://localhost:4000";

// export const API = "https://capstone-student-dashboard.herokuapp.com"

export const API = "https://zenclass-student-dashboard-backend.onrender.com";